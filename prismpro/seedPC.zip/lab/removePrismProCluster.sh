#!/bin/bash

python deleteprismprocluster.py

cd ~/bin
python ./unregistration_cleanup.py 00057d50-00df-b390-0000-00000000eafd
